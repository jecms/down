<?php

//�����Ƿ�����Ƶģ��
$module_db = pc_base::load_model('module_model');
$is_video = $module_db->get_one(array('module'=>'video'),'*');
if(is_array($is_video)){
	//������Ƶ�����Ĳ˵�ID
	$menu_db = pc_base::load_model('menu_model');
	$array = $menu_db->get_one(array('m'=>'video','c'=>'video','a'=>'add'),'*');
	if(!empty($array)){
		$parentid = $array['parentid'];
		//���Ӳ˵� 
	$return_id = $menu_db->insert(array('name'=>'import_ku6_video','parentid'=>$parentid,'m'=>'video','c'=>'video','a'=>'import_ku6video','display'=>1),true); 
	}
	//�����ֶ� 
	$sql = "ALTER TABLE  `phpcms_video_store` ADD  `userupload` TINYINT( 1 ) UNSIGNED NOT NULL DEFAULT  '0';";
	$menu_db->query($sql);
} 

?>