<?php 
defined('IN_PHPCMS') or exit('No permission resources.');

/**
 * 
 * ------------------------------------------
 * video video class
 * ------------------------------------------
 * 
 * ��Ƶ�������չ�µ���Ƶ����������  ������Ƶ���ӡ��޸ġ�ɾ������ku6������Ƶ��
 * �û������ú�ku6vms�˻������ʹ�ø�ģ�顣
 * �ڴ���չ�¶���Ƶ�����в���ͨ���ӿ�ͬ����ku6vms����
 * 
 * @package 	PHPCMS V9.1.16
 * @author		chenxuewang
 * @copyright	CopyRight (c) 2006-2012 �Ϻ�ʢ�����緢չ���޹�˾
 * 
 */
pc_base::load_app_class('admin', 'admin', 0);
pc_base::load_sys_class('form', 0, 0);
pc_base::load_app_func('global', 'video');


class video extends admin {
	
	public $db,$module_db;
	
	public function __construct() {
		parent::__construct();
		$this->db = pc_base::load_model('video_store_model');
		$this->module_db = pc_base::load_model('module_model');
		$this->userid = $_SESSION['userid'];
		pc_base::load_app_class('ku6api', 'video', 0);
		pc_base::load_app_class('v', 'video', 0);
		$this->v =  new v($this->db);
		
		//��ȡ����ƽ̨������Ϣ
		$this->setting = getcache('video');
		if(empty($this->setting) && ROUTE_A!='setting') {
			showmessage(L('video_setting_not_succfull'), 'index.php?m=video&c=video&a=setting&meunid='.$_GET['meunid']);
		}
		$this->ku6api = new ku6api($this->setting['sn'], $this->setting['skey']);
	}
	
	/**
	 * 
	 * ��Ƶ�б�
	 */
	public function init() {
		$where = '1';
		$page = $_GET['page'];
		$pagesize = 20;
		if (isset($_GET['type'])) {
			if ($_GET['type']==1) {
				$where .= ' AND `videoid`=\''.$_GET['q'].'\'';
			} else {
				$where .= " AND `title` LIKE '%".$_GET['q']."%'";
			}
		}
		if (isset($_GET['start_time'])) {
			$where .= ' AND `addtime`>=\''.strtotime($_GET['start_time']).'\'';
		}
		if (isset($_GET['end_time'])) {
			$where .= ' AND `addtime`<=\''.strtotime($_GET['end_time']).'\'';
		}
		if (isset($_GET['status'])) {
			$status = intval($_GET['status']);
			$where .= ' AND `status`=\''.$status.'\'';
		}
		$userupload = intval($_GET['userupload']);
		if ($userupload) {
			$where .= ' AND `userupload`=1';
		}
		$infos = $this->db->listinfo($where, 'videoid DESC', $page, $pagesize);
		$pages = $this->db->pages;
		include $this->admin_tpl('video_list');		
	}
	
	/**
	 * 
	 * ��Ƶ���ӷ���
	 */
	public function add() {
		if ($_POST['dosubmit']) {
			//���ȴ������ύ����������
			$data['vid'] = $_POST['vid'];
			if (!$data['vid']) showmessage(L('failed_you_video_uploading'), 'index.php?m=video&c=video&a=add');
			$data['title'] = isset($_POST['title']) && trim($_POST['title']) ? trim($_POST['title']) : showmessage(L('video_title_not_empty'), 'index.php?m=video&c=video&a=add&meunid='.$_GET['meunid']);
			$data['description'] = trim($_POST['description']);
			$data['keywords'] = trim(strip_tags($_POST['keywords']));
			//�����vms post���ݣ���ȡ�÷���ֵ
			$get_data = $this->ku6api->vms_add($data);
			if (!$get_data) {
				showmessage($this->ku6api->error_msg);
			}
			$data['vid'] = $get_data['vid'];
			$data['addtime'] = SYS_TIME;
			$data['userupload'] = intval($_POST['userupload']);
			$videoid = $this->v->add($data);
			if ($videoid) {
				showmessage(L('operation_success'), 'index.php?m=video&c=video&a=init&meunid='.$_GET['meunid']);
			} else {
				showmessage(L('operation_failure'), 'index.php?m=video&c=video&a=add&meunid='.$_GET['meunid']);
			}
		} else {
			if(!$this->ku6api->testapi()) {
				showmessage(L('vms_sn_skey_error'),'?m=video&c=video&a=setting&menuid='.$_GET['menuid']);
			}
			$flash_info = $this->ku6api->flashuploadparam();
			$show_validator = true;
			include $this->admin_tpl('video_add');
		}
	}
	
	/**
	 * function edit
	 * ��Ƶ�༭������
	 */
	public function edit() {
		$vid = intval($_GET['vid']);
		if (!$vid) showmessage(L('illegal_parameters'));
		if (isset($_POST['dosubmit'])) {
			//���ȴ������ύ����������
			$data['vid'] = $_POST['vid'];
			if (!$data['vid']) showmessage(L('failed_you_video_uploading'), 'index.php?m=video&c=video&a=add');
			$data['title'] = isset($_POST['title']) && trim($_POST['title']) ? trim($_POST['title']) : showmessage(L('video_title_not_empty'), 'index.php?m=video&c=video&a=add&meunid='.$_GET['meunid']);
			$data['description'] = trim($_POST['description']);
			$data['keywords'] = trim(strip_tags($_POST['keywords']));
			//�����vms post���ݣ���ȡ�÷���ֵ
			if ($this->ku6api->vms_edit($data)) {
				$return = $this->v->edit($data, $vid);
				if ($return) showmessage(L('operation_success'), 'index.php?m=video&c=video&a=init');
				else showmessage(L('operation_failure'), 'index.php?m=video&c=video&a=edit&vid='.$vid.'&menuid='.$_GET['menuid']);
			} else {
				showmessage($this->ku6api->error_msg, 'index.php?m=video&c=video&a=edit&vid='.$vid.'&menuid='.$_GET['menuid']);
			}
		} else {
			$show_validator = true;
			$info = $this->db->get_one(array('videoid'=>$vid));
			include $this->admin_tpl('video_edit');
		}
	}
	
	/**
	 * function delete
	 * ɾ����Ƶ������
	 */
	public function delete() {
		$vid = $_GET['vid'];
		$r = $this->db->get_one(array('videoid'=>$vid), 'vid');
		if (!$r) showmessage(L('video_not_exist_or_deleted'));
		if (!$this->ku6api->delete_v($r['vid'])) showmessage(L('operation_failure'), 'index.php?m=video&c=video&a=init&meunid='.$_GET['meunid']);
		$this->v->del_video($vid);	
		showmessage(L('success_next_update_content'), 'index.php?m=video&c=video&a=public_update_content&vid='.$vid.'&meunid='.$_GET['meunid']);
	}
	
	/**
	 * Function UPDATE_CONTENT
	 * ���������Ƶ����������ģ��
	 * @param int $vid ��Ƶ��videoid�ֶ�
	 */
	public function public_update_content() {
		$videoid = intval($_GET['vid']);
		$video_content_db = pc_base::load_model('video_content_model');
		$meunid = intval($_GET['meunid']);
		$pagesize = 10;
		$result = $video_content_db->select(array('videoid'=>$videoid), '*', $pagesize);
		if (!$result || empty($result)) {
			showmessage(L('update_complete'), 'index.php?m=video&c=video&a=init&meunid='.$meunid);
		}
		//���ظ���html��
		$html = pc_base::load_app_class('html', 'content');
		$content_db = pc_base::load_model('content_model');
		$url = pc_base::load_app_class('url', 'content');
		foreach ($result as $rs) {
			$modelid = intval($rs['modelid']);
			$contentid = intval($rs['contentid']);
			$video_content_db->delete(array('videoid'=>$videoid, 'contentid'=>$contentid, 'modelid'=>$modelid));
			$content_db->set_model($modelid);
			$table_name = $content_db->table_name;
			$r1 = $content_db->get_one(array('id'=>$contentid));
			if ($this->ishtml($r1['catid'])) {
				$content_db->table_name = $table_name.'_data';
				$r2 = $content_db->get_one(array('id'=>$contentid));
				$r = array_merge($r1, $r2);unset($r1, $r2);
				if($r['upgrade']) {
					$urls[1] = $r['url'];
				} else {
					$urls = $url->show($r['id'], '', $r['catid'], $r['inputtime']);
				}
				$html->show($urls[1], $r, 0, 'edit');
			} else {
				continue;
			}
		}
		showmessage(L('part_update_complete'), 'index.php?m=video&c=video&a=public_update_content&vid='.$videoid.'&meunid='.$meunid);
	}
	
	/**
	 * Function ISHTML
	 * �ж������Ƿ���Ҫ���ɾ�̬
	 * @param int $catid ��Ŀid
	 */
	private function ishtml($catid = 0) {
		static $ishtml, $catid_siteid;
		if (!$ishtml[$catid]) {
			if (!$catid_siteid) {
				$catid_siteid = getcache('category_content', 'commons');
			} else {
				$siteid = $catid_siteid[$catid];
			}
			$siteid = $catid_siteid[$catid];
			$categorys = getcache('category_content_'.$siteid, 'commons');
			$ishtml[$catid] = $categorys[$catid]['content_ishtml'];
		}
		return $ishtml[$catid];
	}
	
	/**
	 * 
	 * ������Ƶ��������������ʶ���롢������Կ�����÷�����ŵ���Ϣ
	 */
	public function setting() {
		if(isset($_POST['dosubmit'])) {
			$setting = array2string($_POST['setting']);
			setcache('video', $_POST['setting']);
			$this->ku6api->ku6api_skey = $_POST['setting']['skey'];
			$this->ku6api->ku6api_sn = $_POST['setting']['sn'];
			$this->module_db->update(array('setting'=>$setting),array('module'=>'video'));
			if(!$this->ku6api->testapi()) {
				showmessage(L('vms_sn_skey_error'),HTTP_REFERER);
			}
			showmessage(L('operation_success'),HTTP_REFERER);
		} else {
			$show_pc_hash = '';
			$v_model_categorys = $this->ku6api->get_categorys(true, $this->setting['catid']);
			$category_list = '<select name="setting[catid]" id="catid"><option value="0">'.L('please_choose_catid').'</option>'.$v_model_categorys.'</select>';
			include $this->admin_tpl('video_setting');
		}
	}
	
	/**
	 * function get_pos ��ȡ�Ƽ�λ
	 * ������Ŀ��ȡ�Ƽ�λid��������form��select��ʽ
	 */
	public function public_get_pos () {
		$catid = intval($_GET['catid']);
		if (!$catid) exit(0);
		$position = getcache('position','commons');
		if(empty($position)) exit;
		$category = pc_base::load_model('category_model');
		$info = $category->get_one(array('catid'=>$catid), 'modelid, arrchildid');
		if (!$info) exit(0);
		$modelid = $info['modelid'];
		$array = array();
		foreach($position as $_key=>$_value) {
			if($_value['modelid'] && ($_value['modelid'] !=  $modelid) || ($_value['catid'] && strpos(','.$info['arrchildid'].',',','.$catid.',')===false)) continue;
			$array[$_key] = $_value['name'];
		}
		$data = form::select($array, '', 'name="sub[posid]"', L('please_select'));
		exit($data);
	}
	
	/**
	 * Function subscribe_list ��ȡ�����б�
	 * ��ȡ�����б�
	 */
	public function subscribe_list() {
		if (isset($_POST['dosubmit'])) {
			if (is_array($_POST['sub']) && !empty($_POST['sub'])) {
				$sub = $_POST['sub'];
				if (!$sub['channelid'] || !$sub['catid']) showmessage(L('please_choose_catid_and_channel'));
				$sub['catid'] = intval($sub['catid']);
				$sub['posid'] = intval($sub['posid']);
				$result = $this->ku6api->subscribe($sub);
				if ($result['check'] == 6) showmessage(L('subscribe_for_default')); 
				if ($result['code'] == 200) showmessage(L('operation_success'), 'index.php?m=video&c=video&a=subscribe_list');
				else showmessage(L('subscribe_set_failed'), 'index.php?m=video&c=video&a=subscribe_list&meunid='.$_GET['meunid']);
			} else {
				showmessage(L('please_choose_catid_and_channel'), 'index.php?m=video&c=video&a=subscribe_list&meunid='.$_GET['meunid']);
			}
		} else {
			if(!$this->ku6api->testapi()) {
				showmessage(L('vms_sn_skey_error'),'?m=video&c=video&a=setting&menuid='.$_GET['menuid']);
			}
			//��ȡ�û�������Ϣ
			$v_model_categorys = $this->ku6api->get_categorys(true);
			$category_list = '<select name="sub[catid]" id="catid" onchange="select_pos(this)"><option value="0">'.L('please_choose_catid').'</option>'.$v_model_categorys.'</select>';
			$siteid = get_siteid();
			$CATEGORYS = getcache('category_content_'.$siteid, 'commons');
			$ku6_channels = $this->ku6api->get_subscribetype();
			$subscribes = $this->ku6api->get_subscribe();
			$position = getcache('position','commons');
			
			include $this->admin_tpl('subscribe_list');
		}
	}
	
	/**
	 * Function Sub_DEl ɾ������
	 * �û�ɾ�����ķ���
	 */
	public function sub_del() {
		$id = intval($_GET['id']);
		if (!$id) showmessage(L('illegal_parameters'), 'index.php?m=video&c=video&a=subscribe_list&meunid='.$_GET['meunid']);
		if ($this->ku6api->sub_del($id)) showmessage(L('operation_success'), 'index.php?m=video&c=video&a=subscribe_list&meunid='.$_GET['meunid']);
		else showmessage(L('delete_failed'), 'index.php?m=video&c=video&a=subscribe_list&meunid='.$_GET['meunid']);
	}
	
	/**
	 * Function video2content ��Ƶ������Ƶ
	 * �û�ѡ������Ƶ��ѡ�����ϴ�����Ƶ���뵽��Ƶ�ֶλ�༭����
	 */
	public function video2content () {
		$page = max(intval($_GET['page']), 1);
		$pagesize = 8;
		$where = '`status` = 21';
		if (isset($_GET['name']) && !empty($_GET['name'])) {
			$title = safe_replace($_GET['name']);
			$where .= " AND `title` LIKE '%$title%'";
		}
		if (isset($_GET['starttime']) && !empty($_GET['starttime'])) {
			$addtime = strtotime($_GET['starttime']);
			$where .= " AND `addtime`>='$addtime'";
		}
		if (isset($_GET['endtime']) && !empty($_GET['endtime'])) {
			$endtime = strtotime($_GET['endtime']);
			$where .= " AND `addtime` <= '$endtime'";
		}
		if ($_GET['userupload']) {
			$userupload = intval($_GET['userupload']);
			$where .= " AND `userupload`=1";
		}
		$show_header = 1;
		$infos = $this->db->listinfo($where, '`videoid` DESC', $page, $pagesize, '', 5);
		$pages = $this->db->pages;
		include $this->admin_tpl('album_list');
	}
	
	/**
	 * ����swfupload�ϴ���json��ʽcookie
	 */
	public function swfupload_json() {
		$arr['id'] = intval($_GET['id']);
		$arr['src'] = trim($_GET['src']);
		$arr['title'] = urlencode($_GET['title']);
		$json_str = json_encode($arr);
		$att_arr_exist = param::get_cookie('att_json');
		$att_arr_exist_tmp = explode('||', $att_arr_exist);
		if(is_array($att_arr_exist_tmp) && in_array($json_str, $att_arr_exist_tmp)) {
			return true;
		} else {
			$json_str = $att_arr_exist ? $att_arr_exist.'||'.$json_str : $json_str;
			param::set_cookie('att_json',$json_str);
			return true;			
		}
	}
	
	/**
	 * ɾ��swfupload�ϴ���json��ʽcookie
	 */	
	public function swfupload_json_del() {
		$arr['aid'] = intval($_GET['aid']);
		$arr['src'] = trim($_GET['src']);
		$arr['filename'] = urlencode($_GET['filename']);
		$json_str = json_encode($arr);
		$att_arr_exist = param::get_cookie('att_json');
		$att_arr_exist = str_replace(array($json_str,'||||'), array('','||'), $att_arr_exist);
		$att_arr_exist = preg_replace('/^\|\|||\|\|$/i', '', $att_arr_exist);
		param::set_cookie('att_json',$att_arr_exist);
	}

	/**
	* ����KU6��Ƶ
	*/
	public function import_ku6video(){
		pc_base::load_sys_class('format','',0);
		$do = isset($_GET['do']) ? $_GET['do'] : '';
		$ku6url = isset($_GET['ku6url']) ? $_GET['ku6url'] : '';
		$time = isset($_GET['time']) ? $_GET['time'] : '';
		$keyword = isset($_GET['keyword']) ? $_GET['keyword'] : '*:*';
		$len = isset($_GET['len']) ? $_GET['len'] : '';//ʱ��s:С��4���� I:����4����
		$fenlei = isset($_GET['fenlei']) ? $_GET['fenlei'] : '*:*';//��������
		$srctype = isset($_GET['srctype']) ? $_GET['srctype'] : '*:*';//��Ƶ���� 
		$videotime = isset($_GET['videotime']) ? $_GET['videotime'] : '*:*';//��Ƶ���� 
 		$page = isset($_GET['page']) ? $_GET['page'] : '1';
		$pagesize = 7;
 		$list = array();
		$fq = '';
		
		if(CHARSET!='utf-8'){
			$keyword = iconv('gbk', 'utf-8', $keyword);
		}
		$keyword = urlencode($keyword);
		//������������ 
		if ($fenlei !== '*:*' && $fenlei!='') {
				$keyword .= '%20categoryid:' . $fenlei;
		}
		//��Ƶ�������� 
		if ($srctype !== '*:*' && $srctype!='') {
				if ($srctype == '1') {
					$keyword .= '%20srctype:[0%20TO%201]';				
				} elseif ($srctype == '2') {
					$keyword .= '%20srctype:[2%20TO%203]';				
				} elseif ($srctype == '3') {
					$keyword .= '%20srctype:[4%20TO%207]';				
				}
		}
		
		if($videotime!=''){
			if($videotime == '1'){
				$fq .= '[0%20TO%20600]';
			}elseif($videotime == '2'){
				$fq .= '[600%20TO%201800]';
			}elseif($videotime == '3'){
				$fq .= '[1800%20TO%203600]';
			}elseif($videotime == '4'){
				$fq .= '[3600%20TO%20*]';
			}
 		}
  		$data = $this->ku6api->Ku6search($keyword,$pagesize,$page,$len,$fenlei,$fq); 
 		$totals = $data['data']['response']['numFound'];
		$list = $data['data']['response']['docs'];
		//��ȡ��Ƶ��С�ӿ�
		if(isset($list) && is_array($list) && count($list) > 0) {
			foreach ($list as $key=>$v) {
				$spaceurl = "http://v.ku6.com/fetchVideo4Player/1/$v[vid].html";
				$spacejson = file_get_contents($spaceurl);
				$space = json_decode($spacejson, 1);	 
				$list[$key]['size'] = $space['data']['videosize'];
				$list[$key]['uploadTime']  = substr($v['uploadtime'], 0, 10); 
				//�ж���Щ�Ѿ����������ϵͳ $vidstr .= ',\''.$v['vid'].'\'';
			}
		}   
		//ѡ��վ�����Ŀ���е���
		$sitelist = getcache('sitelist','commons');
		
		//��������
		$fenlei_array = array('101000'=>'��Ѷ','102000'=>'����','103000'=>'����','104000'=>'��Ӱ','105000'=>'ԭ��','106000'=>'���','107000'=>'��Ů','108000'=>'��Ц','109000'=>'��Ϸ','110000'=>'����','111000'=>'����','113000'=>'����','114000'=>'����','115000'=>'����','116000'=>'����','117000'=>'����','118000'=>'����','125000'=>'Ů��','126000'=>'��¼','127000'=>'�Ƽ�','190000'=>'����');
		//��Ƶ����
		$srctype_array = array('1'=>'����','2'=>'����','3'=>'����');
 		$videotime_array = array('1'=>'����Ƶ','2'=>'��ͨ��Ƶ','3'=>'����Ƶ','4'=>'����Ƶ');
		
		//������Ƶ��Ŀ
		$categoryrr = $this->get_category();
  		include $this->admin_tpl('import_ku6video');   
 	}

	/**
	* ������Ƶ��� 
	*/
	public function preview_ku6video(){
		$ku6vid = $_GET['ku6vid'];
 		$data = $this->ku6api->Preview($ku6vid);
   		include $this->admin_tpl('priview_ku6video');
	}
	
	/**
	* ��ȡվ����Ŀ����
	*/
	public function get_category(){
  		$siteid = get_siteid();//ֱȡSITEIDֵ
		$sitemodel_field = pc_base::load_model('sitemodel_field_model');
		$result = $sitemodel_field->select(array('formtype'=>'video', 'siteid'=>$siteid), 'modelid');
		if (is_array($result)) {
			$models = '';
			foreach ($result as $r) {
				$models .= $r['modelid'].',';
			}
		}
		$models = substr(trim($models), 0, -1);
		$cat_db = pc_base::load_model('category_model');
		if ($models) {
			$where = '`modelid` IN ('.$models.') AND `type`=0 AND `siteid`=\''.$siteid.'\'';
			$result = $cat_db->select($where, '`catid`, `catname`, `parentid`, `siteid`, `child`');
			if (is_array($result)) { 
				$data = $return_data = $categorys = array(); 
				$tree = pc_base::load_sys_class('tree');   
				$data = $return_data = $categorys = array(); 
				$tree = pc_base::load_sys_class('tree');//factory::load_class('tree', 'utils');
 				$string = '<select name="select_category" id="select_category" onchange="select_pos(this)">';
				$string .= "<option value=0>��ѡ�����</option>";
				foreach ($result as $r) {
					$r['html_disabled'] = "";
					if ($r['child']) {
						$r['html_disabled'] = "disabled";
					} 
					$categorys[$r['catid']] = $r;
				}
				$str  = $str2 = "<option value=\$catid \$html_disabled \$selected>\$spacer \$catname</option>"; 			     $tree->init($categorys);
				$string .= $tree->get_tree_category(0, $str, $str2);
 				$string .= '</select>';
				return $string;//��ʹ��ǰ̨js���ã�ʹ��return ;
			}
 		}
		return array();
	}
}

?>