	function title($field, $value) {
		$value = new_html_special_chars($value);
		return $value;
	}
