<?php 
defined('IN_PHPCMS') or exit('Access Denied');
defined('INSTALL') or exit('Access Denied');

$module = 'wap';
$modulename = '�ֻ��Ż�';
$introduce = '����ģ��';
$author = 'phpcms Team';
$authorsite = 'http://www.phpcms.cn';
$authoremail = '';
?>