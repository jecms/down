<table cellpadding="2" cellspacing="1" width="98%">
	<tr> 
      <td width="100">�ı������</td>
      <td><input type="text" name="setting[width]" value="<?php echo $setting['width'];?>" size="10" class="input-text" > %</td>
    </tr>
	<tr> 
      <td>�ı���߶�</td>
      <td><input type="text" name="setting[height]" value="<?php echo $setting['height'];?>" size="10" class="input-text"> px</td>
    </tr>
	<tr> 
      <td>Ĭ��ֵ</td>
      <td><textarea name="setting[defaultvalue]" rows="2" cols="20" id="defaultvalue" style="height:60px;width:250px;" ><?php echo htmlspecialchars($setting['defaultvalue']);?></textarea></td>
    </tr>
	<tr> 
      <td>�Ƿ�����Html</td>
      <td><input type="radio" name="setting[enablehtml]" value="1" <?php if($setting['enablehtml']==1) {?>checked<?php }?>> �� <input type="radio" name="setting[enablehtml]" value="0" <?php if($setting['enablehtml']==0) {?>checked<?php }?>> ��</td>
    </tr>
</table>