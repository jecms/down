<table cellpadding="2" cellspacing="1" width="98%">
	<tr> 
      <td width="100">������С</td>
      <td><input type="text" name="setting[size]" value="<?php echo $setting['size'];?>" size="6" class="input-text"></td>
    </tr>
</table>