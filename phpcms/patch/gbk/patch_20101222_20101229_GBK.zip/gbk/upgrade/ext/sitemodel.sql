ALTER TABLE `phpcms_model` ADD `js_template` VARCHAR( 30 ) NOT NULL AFTER `show_template`;
ALTER TABLE `phpcms_model` ADD `items` SMALLINT UNSIGNED NOT NULL DEFAULT '0' AFTER `tablename` ;
ALTER TABLE `phpcms_model` ADD `addtime` INT UNSIGNED NOT NULL DEFAULT '0' AFTER `tablename` ;
ALTER TABLE `phpcms_model` ADD `setting` TEXT NOT NULL COMMENT '������Ϣ' AFTER `tablename` ;

ALTER TABLE `phpcms_model` ADD INDEX ( `type` , `siteid` ) ;