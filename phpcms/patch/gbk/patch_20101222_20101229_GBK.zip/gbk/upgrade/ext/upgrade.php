<?php
$sites = getcache('sitelist', 'commons');

$menu_db = pc_base::load_model('menu_model');
$menu_db->delete(array('m'=>'message', 'name'=>'my_inbox'));
$menu_db->delete(array('m'=>'message', 'name'=>'my_outbox'));
$module_db = pc_base::load_model('module_model');
$module = array(array('module'=> 'search', 'data'=>'search'), 'link', 'vote', 'poster');
foreach($module as $m) {
	$setting = array();
	if (is_array($m)) {
		$module_name = $m['module'];
		$file = $m['file'] ? $m['file'] : $m['module'];
		$data = $m['data'] ? $m['data'] : $m['module'];
		$r = $module_db->get_one(array('module'=>$module_name), 'setting');
		foreach ($sites as $sid => $s) {
			$setting[$sid] = string2array($r['setting']);
		}
		delcache($file, $data);
		setcache($file, $setting, $data);
		$setting = array2string($setting);
		$module_db->update(array('setting'=>$setting), array('module'=>$module_name));
	} else {
		$r = $module_db->get_one(array('module'=>$m), 'setting');
		foreach ($sites as $sid => $s) {
			$setting[$sid] = string2array($r['setting']);
		}
		delcache($m, 'commons');
		setcache($m, $setting, 'commons');
		$setting = array2string($setting);
		$module_db->update(array('setting'=>$setting), array('module'=>$m));
	}
}
$data = $moods = array();
$moods = getcache('mood_program', 'commons');
foreach($sites as $sid => $s) {
	$data[$sid] = $moods;
}
setcache('mood_program', $data, 'commons');
?>