<?php 
defined('IN_PHPCMS') or exit('Access Denied');
defined('INSTALL') or exit('Access Denied');
$module = 'sms';
$modulename = '����ƽ̨';
$introduce = '����ƽ̨';
$author = 'phpcms team';
$authorsite = 'http://www.phpcms.cn';
$authoremail = '';
?>