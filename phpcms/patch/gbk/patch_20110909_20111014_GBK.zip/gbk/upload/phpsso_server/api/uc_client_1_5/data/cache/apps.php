<?php
$_CACHE['apps'] = array (
  1 => 
  array (
    'appid' => '1',
    'type' => 'DISCUZ',
    'name' => 'Discuz!',
    'url' => 'http://localhost/test/dz',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => 'gbk',
    'dbcharset' => 'gbk',
    'synlogin' => '1',
    'recvnote' => '1',
    'extra' => false,
    'tagtemplates' => '<?xml version="1.0" encoding="ISO-8859-1"?>
<root>
	<item id="template"><![CDATA[<a href="{url}" target="_blank">{subject}</a>]]></item>
	<item id="fields">
		<item id="subject"><![CDATA[����]]></item>
		<item id="uid"><![CDATA[�û� ID]]></item>
		<item id="username"><![CDATA[������]]></item>
		<item id="dateline"><![CDATA[����]]></item>
		<item id="url"><![CDATA[�����ַ]]></item>
	</item>
</root>',
  ),
  2 => 
  array (
    'appid' => '2',
    'type' => 'OTHER',
    'name' => 'phpsso',
    'url' => 'http://www.phpsso.cn',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => '',
    'dbcharset' => '',
    'synlogin' => '1',
    'recvnote' => '1',
    'extra' => false,
    'tagtemplates' => '<?xml version="1.0" encoding="ISO-8859-1"?>
<root>
	<item id="template"><![CDATA[]]></item>
</root>',
  ),
  3 => 
  array (
    'appid' => '3',
    'type' => 'UCHOME',
    'name' => '���˼�԰',
    'url' => 'http://localhost/test/uchome',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => 'gbk',
    'dbcharset' => 'gbk',
    'synlogin' => '1',
    'recvnote' => '1',
    'extra' => false,
    'tagtemplates' => '<?xml version="1.0" encoding="ISO-8859-1"?>
<root>
	<item id="template"><![CDATA[<a href="{url}" target="_blank">{subject}</a>]]></item>
	<item id="fields">
		<item id="subject"><![CDATA[��־����]]></item>
		<item id="uid"><![CDATA[�û� ID]]></item>
		<item id="username"><![CDATA[�û���]]></item>
		<item id="dateline"><![CDATA[����]]></item>
		<item id="spaceurl"><![CDATA[�ռ��ַ]]></item>
		<item id="url"><![CDATA[��־��ַ]]></item>
	</item>
</root>',
  ),
);

?>