<?php
/**
 * Description:
 * 
 * Project:    PhpCms
 * Encoding:    GBK
 * Created on:  2012-4-16-����4:40:19
 * Author:     kangyun
 * Email:       KangYun.Yun@Snda.Com
 */
 
defined('IN_PHPCMS') or exit('Access Denied');
defined('INSTALL') or exit('Access Denied');
$module = 'maillist';
$modulename = '�ʼ���';
$introduce = '�ʼ�Ⱥ��ģ��';
$author = '����';
$authorsite = 'http://o.sdo.com';
$authoremail = 'kangyun.yun@snda.com';
