<?php

if (module_exists('video')) {
	$video_store = pc_base::load_model('video_store_model');
	if (!$video_store->field_exists('channelid')) {
		$video_store->query("ALTER TABLE  `phpcms_video_store` ADD  `channelid` TINYINT UNSIGNED NOT NULL DEFAULT  '1'");
	}
}
?>