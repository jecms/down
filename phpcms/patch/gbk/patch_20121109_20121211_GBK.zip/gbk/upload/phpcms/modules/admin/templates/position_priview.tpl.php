<?php
defined('IN_ADMIN') or exit('No permission resources.');
include $this->admin_tpl('header');?> 
<a href="<?php echo $thumb;?>" target="_blank"><Img src="<?php echo $thumb;?>" title="����򿪴�ͼ" width="500" height="450"></a>
</body> 
</html>