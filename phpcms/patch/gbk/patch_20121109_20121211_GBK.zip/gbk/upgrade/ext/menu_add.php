<?php
if (module_exists('video')) {
	$menu_db = pc_base::load_model('menu_model');

	$r = $menu_db->get_one(array('name'=>'video_manage', 'parentid'=>821, 'm'=>'video'), 'id');
	$parentid = intval($r['id']);
	$menu_db->insert(array('name'=>'video_store', 'parentid'=>$parentid, 'm'=>'video', 'c'=>'video', 'a'=>'video2content', 'listorder'=>0, 'display'=>0));
}
?>