升级说明：
1、上传upload中的文件到网站根目录，覆盖原有文件。
2、登录后台-更新缓存

本补丁适用于20170503版本 升级到20170515版本。

更新说明：
	修复down.php下载漏洞
	修复登录的一处sql注入漏洞
	加强多出加解密key的生成
	修改几个语言包的文字错误

特别说明：
	安装后没修改过auth_key的phpcms用户，请及时修改一下，防止被爆破。
	位置：
	caches\configs\system.php
	phpsso_server\caches\configs\system.php