<?php 
defined('IN_PHPCMS') or exit('Access Denied');
defined('INSTALL') or exit('Access Denied');

$module = 'tag';
$modulename = '��ǩ��';
$introduce = '����ģ��';
$author = 'phpcms Team';
$authorsite = 'http://www.phpcms.cn';
$authoremail = '';
?>