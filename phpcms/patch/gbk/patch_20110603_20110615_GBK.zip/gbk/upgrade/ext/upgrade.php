<?php

$menu_db = pc_base::load_model('menu_model');
$menu_db->insert(array('id'=>9, 'name'=>'plugin', 'parentid'=>0, 'm'=>'admin', 'c'=>'plugin', 'a'=>'init', 'data'=>'', 'listorder'=>8, 'display'=>'1'), true);
$pid = $menu_db->insert(array('name'=>'plugin', 'parentid'=>9, 'm'=>'admin', 'c'=>'plugin', 'a'=>'init', 'data'=>'', 'listorder'=>0, 'display'=>'1'), true);
$cid = $menu_db->insert(array('name'=>'appcenter', 'parentid'=>$pid, 'm'=>'admin', 'c'=>'plugin', 'a'=>'appcenter', 'data'=>'', 'listorder'=>0, 'display'=>'1'), true);
$menu_db->insert(array('name'=>'appcenter_detail', 'parentid'=>$cid, 'm'=>'admin', 'c'=>'plugin', 'a'=>'appcenter_detail', 'data'=>'', 'listorder'=>0, 'display'=>'0'));
$menu_db->insert(array('name'=>'install_online', 'parentid'=>$cid, 'm'=>'admin', 'c'=>'plugin', 'a'=>'install_online', 'data'=>'', 'listorder'=>0, 'display'=>'0'));
$cid = $menu_db->insert(array('name'=>'plugin_list', 'parentid'=>$pid, 'm'=>'admin', 'c'=>'plugin', 'a'=>'init', 'data'=>'', 'listorder'=>1, 'display'=>'1'),true);
$menu_db->insert(array('name'=>'plugin_close', 'parentid'=>$cid, 'm'=>'admin', 'c'=>'plugin', 'a'=>'status', 'data'=>'', 'listorder'=>0, 'display'=>'0'));
$menu_db->insert(array('name'=>'uninstall_plugin', 'parentid'=>$cid, 'm'=>'admin', 'c'=>'plugin', 'a'=>'delete', 'data'=>'', 'listorder'=>0, 'display'=>'0'));
$cid = $menu_db->insert(array('name'=>'plugin_import', 'parentid'=>$pid, 'm'=>'admin', 'c'=>'plugin', 'a'=>'import', 'data'=>'', 'listorder'=>2, 'display'=>'1'));
?>