﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang('capture','zh-cn',{capture:{title:'PHPCMS在线截图',notice:'PHPCMS在线截图控件安装',notice_tips:'<p id="Capture">你还没有安装截图插件！<br />请使用 <a href="http://www.phpcms.cn/capture/" id="CaptureDownWeb" target="_blank">在线安装</a><font>(荐)</font> 或者 <a href="http://www.phpcms.cn/capture/capture.exe" id="CaptureDown" target="_blank">立即下载</a> 方式来安装插件。</p>',unsport_tips:'对不起，本功能暂时只支持IE浏览器'}});
