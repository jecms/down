<?php

$menu_db = pc_base::load_model('menu_model');
if (!$menu_db->get_one(array('m'=>'content', 'c'=>'content', 'm'=>'listorder'))) {
	$menu_db->insert(array('name'=>'listorder', 'parentid'=>'822', 'm'=>'content', 'c'=>'content', 'a'=>'listorder'));
}
?>