<?php defined('IN_PHPCMS') or exit('No permission resources.');?>
<table cellpadding="2" cellspacing="1" width="98%">
	<tr> 
      <td width="200">ÿ��λ�ÿ���</td>
      <td><input type="text" name="setting[width]" value="<?php echo $setting['width'];?>" size="5" class="input-text"> px
	  </td>
    </tr>
    <tr> 
      <td>Ĭ��ѡ����</td>
      <td><input type="text" name="setting[defaultvalue]" value="<?php echo $setting['defaultvalue'];?>" size="20" class="input-text"> ���֮���ð�Ƕ��Ÿ���
	  </td>
    </tr>
</table>