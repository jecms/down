<?php
define('PHPCMS_PATH', dirname(__FILE__).DIRECTORY_SEPARATOR);

include PHPCMS_PATH.'/phpcms/base.php';

pc_base::load_sys_class('param','','','0');
$hits_db = pc_base::load_model('hits_model');
$page = max(intval($_GET['page']), 1);
if ($page == 1) {
	$r = $hits_db->get_one(array('catid'=>0), 'COUNT(*) AS num');
	$total = $r['num'];
	$pages = ceil($total/30);
} else {
	$pages = intval($_GET['pages']);
}
$offset = ($page-1)*30;
$result = $re = array();
$result = $hits_db->select(array(), 'hitsid', $offset.',30', 'hitsid ASC');
$content_db = pc_base::load_model('content_model');
$models = getcache('model', 'commons');
foreach ($result as $k => $re) {
	$hits_arr = array();
	$hits_arr = explode('-', $re['hitsid']);
	if (trim($hits_arr[0])!='c') continue;
	$modelid = intval(trim($hits_arr[1]));
	$id = intval(trim($hits_arr[2]));
	if (!$models[$modelid]['tablename']) continue;
	$content_db->set_model($modelid);
	$c_r = $content_db->get_one(array('id'=>$id), 'catid');
	$catid = $c_r['catid'];
	$hits_db->update(array('catid'=>$catid), array('hitsid'=>$re['hitsid']));
}
if ($page>$pages) {
	echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=7" />
<title>phpcms V9 升级向导</title>
<link href="install/css/install.css" rel="stylesheet" type="text/css" />
<script language="JavaScript" src="install/images/jquery.min.js"></script>
<script language="javascript" type="text/javascript" src="install/images/formvalidator.js" charset="UTF-8"></script>
<script language="javascript" type="text/javascript" src="install/images/formvalidatorregex.js" charset="UTF-8"></script>
</head>
<body>
<div class="body_box">
        <div class="main_box">
            <div class="hd" style="height:170px;">
            	<div class=""><div class="jj_bg"></div></div>
            </div>
            <div class="ct">
            	<div class="bg_t"></div>
                <div class="clr">
                    <div class="l"></div>
                    <div class="ct_box nobrd set7s">
                     <div class="nr">
						<div class="gxwc"><h1>恭喜您，升级成功！</h1></div>
						<div class="clj">
							<ul>
								<li><a href="index.php?m=admin&c=index" title="后台管理" class="htgl">后台管理</a></li>
							</ul>
						</div>					
						<div class="txt_c">
						
						</div>
                     </div>
                    </div>
                </div>
                <div class="bg_b"></div>
            </div>
            <div class="h65"></div>
			<form id="install" action="install.php?" method="get">
			<input type="hidden" name="step" value="7">
        </div>
    </div>
</body>
</html>';
@unlink('./upgrade_hits.php');exit;
} else {
	$page++;
	showmessage('更新完成，更新下一部分', '?page='.$page.'&pages='.$pages);
}

?>