<?php

$menu_db = pc_base::load_model('menu_model');
$mid = $menu_db->insert(array('name'=>'comment_manage', 'parentid'=>821, 'm'=>'comment', 'c'=>'comment_admin', 'a'=>'listinfo', 'data'=>'', 'listorder'=>0, 'display'=>'1'), true);
$menu_db->update(array('parentid'=>$mid), array('m'=>'comment', 'c'=>'check'));
$file = PC_PATH.'languages'.DIRECTORY_SEPARATOR.pc_base::load_config('system', 'lang').DIRECTORY_SEPARATOR.'system_menu.lang.php';
if(file_exists($file)) {
	$content = file_get_contents($file);
	$content = substr($content,0,-2);
	$data = '';
	$data .= "\$LANG['comment_manage'] = '评论管理';\n\r";
	$data = $content.$data."?>";
	file_put_contents($file,$data);
}
?>