<?php
return array(
'pc_version' => 'V9.5.9',	//phpcms 版本号
'pc_release' => '20150305',	//phpcms 更新日期
);
?>