ALTER TABLE `phpcms_linkage` ADD `child` TINYINT( 1 ) UNSIGNED NOT NULL DEFAULT '0' AFTER `parentid`;
ALTER TABLE `phpcms_linkage` ADD `arrchildid` MEDIUMTEXT NOT NULL AFTER `child`;