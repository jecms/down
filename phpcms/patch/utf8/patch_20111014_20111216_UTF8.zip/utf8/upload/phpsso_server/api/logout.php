<?php
defined('IN_PHPCMS') or exit('No permission resources.'); 

param::set_cookie('username', '');
param::set_cookie('userid', '');