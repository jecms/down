<?php

$menu_db = pc_base::load_model('menu_model');
if (!$menu_db->field_exists('project1')) {
	$menu_db->query('ALTER TABLE  `phpcms_menu` ADD  `project1` TINYINT( 1 ) UNSIGNED NOT NULL DEFAULT  \'1\', ADD  `project2` TINYINT( 1 ) UNSIGNED NOT NULL DEFAULT  \'1\', ADD  `project3` TINYINT( 1 ) UNSIGNED NOT NULL DEFAULT  \'1\', ADD  `project4` TINYINT( 1 ) UNSIGNED NOT NULL DEFAULT  \'1\', ADD  `project5` TINYINT( 1 ) UNSIGNED NOT NULL DEFAULT  \'1\'');
}
$position_db = pc_base::load_model('position_model');
if (!$position_db->field_exists('thumb')) {
	$position_db->query('ALTER TABLE  `phpcms_position` ADD  `thumb` CHAR( 200 ) NOT NULL;');
}
$site_model_db = pc_base::load_model('sitemodel_model');
if (!$site_model_db->field_exists('admin_list_template')) {
	$site_model_db->query("ALTER TABLE  `phpcms_model` ADD  `admin_list_template` CHAR( 20 ) NOT NULL AFTER  `js_template` , ADD  `member_add_template` CHAR( 20 ) NOT NULL AFTER  `admin_list_template` , ADD  `member_list_template` CHAR( 20 ) NOT NULL AFTER  `member_add_template`");
}
$menu_db->update(array('project1'=>0, 'project2'=>0, 'project3'=>0, 'project4'=>0, 'project5'=>0), "`id` IN (10, 1, 6, 7, 8, 9)");
?>