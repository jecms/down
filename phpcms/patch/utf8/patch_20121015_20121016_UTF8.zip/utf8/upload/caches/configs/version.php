<?php
return array(
'pc_version' => 'V9.2.2',	//phpcms 版本号
'pc_release' => '20121016',	//phpcms 更新日期
);
?>