<?php
return array(
'pc_version' => 'V9.5.3',	//phpcms 版本号
'pc_release' => '20140121',	//phpcms 更新日期
);
?>