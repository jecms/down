<?php
/**
 * Description:
 * 
 * Project:    PhpCms
 * Encoding:    GBK
 * Created on:  2012-4-16-下午4:40:19
 * Author:     kangyun
 * Email:       KangYun.Yun@Snda.Com
 */
 
defined('IN_PHPCMS') or exit('Access Denied');
defined('INSTALL') or exit('Access Denied');
$module = 'maillist';
$modulename = '邮件组';
$introduce = '邮件群发模块';
$author = '康允';
$authorsite = 'http://o.sdo.com';
$authoremail = 'kangyun.yun@snda.com';
