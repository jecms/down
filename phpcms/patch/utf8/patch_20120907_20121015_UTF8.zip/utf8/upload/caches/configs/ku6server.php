<?php
return array(
	//站外视频上传接口地址
	'api_url' => 'http://v.ku6vms.com/v2/api',
	'player_url' => 'http://v.ku6vms.com/phpvms/player/html/vid/',
);
?>