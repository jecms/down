<?php
return array(
'pc_version' => 'V9.1.18',	//phpcms 版本号
'pc_release' => '20120907',	//phpcms 更新日期
);
?>