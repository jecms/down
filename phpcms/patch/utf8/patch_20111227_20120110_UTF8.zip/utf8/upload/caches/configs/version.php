<?php
return array(
'pc_version' => 'V9.1.12',	//phpcms 版本号
'pc_release' => '20120110',	//phpcms 更新日期
);
?>