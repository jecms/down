<?php
return array(
'pc_version' => 'V9.5.5',	//phpcms 版本号
'pc_release' => '20140430',	//phpcms 更新日期
);
?>