<?php
return array(
'pc_version' => 'V9.2.7',	//phpcms 版本号
'pc_release' => '20130110',	//phpcms 更新日期
);
?>