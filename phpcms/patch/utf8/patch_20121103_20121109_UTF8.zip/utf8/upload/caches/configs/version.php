<?php
return array(
'pc_version' => 'V9.2.4',	//phpcms 版本号
'pc_release' => '20121109',	//phpcms 更新日期
);
?>