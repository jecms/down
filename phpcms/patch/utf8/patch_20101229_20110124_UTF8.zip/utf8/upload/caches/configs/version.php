<?php
return array(
'pc_version' => 'V9.0.1',	//phpcms 版本号
'pc_release' => '20110124',	//phpcms 更新日期
);
?>