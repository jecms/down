<?php
return array(
'pc_version' => 'V9.0.8',	//phpcms 版本号
'pc_release' => '20110413',	//phpcms 更新日期
);
?>