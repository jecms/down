<?php
return array(
'pc_version' => 'V9.0.3',	//phpcms 版本号
'pc_release' => '20110214',	//phpcms 更新日期
);
?>