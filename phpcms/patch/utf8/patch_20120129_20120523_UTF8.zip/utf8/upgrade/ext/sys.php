<?php
$configfile = CACHE_PATH.'configs'.DIRECTORY_SEPARATOR.'system'.'.php';
$str = file_get_contents($configfile);
$arr = explode(");",$str);
$arr[0] = $arr[0].'\'qq_appid\' => \'\',
  \'qq_appkey\' => \'\',
  \'qq_callback\' => \'\',';
  
$new_arr = $arr[0].');'.$arr[1];
file_put_contents($configfile, $new_arr);
?>