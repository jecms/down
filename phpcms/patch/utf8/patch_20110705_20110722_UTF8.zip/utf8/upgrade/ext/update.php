<?php

$system_config = @file_get_contents(CACHE_PATH.'configs'.DIRECTORY_SEPARATOR.'system.php');
$system_config = substr($system_config,0,strpos($system_config, ')'));
$add_arr = array('snda_akey'=>'盛大通行证 akey', 'snda_skey'=>'盛大通行证 skey', 'qq_akey'=>'qq akey', 'qq_skey'=>'qq skey');
foreach ($add_arr as $k => $a) {
	$system_config .= '\''.$k.'\' => \'\',	//'.$a."\r\n";
}
$system_config = str_replace('\'snda_enable\' => \'blue\',	//是否开启盛大通行证', '', $system_config);
$system_config .= ");\r\n?>";
file_put_contents(CACHE_PATH.'configs'.DIRECTORY_SEPARATOR.'system.php', $system_config);
?>