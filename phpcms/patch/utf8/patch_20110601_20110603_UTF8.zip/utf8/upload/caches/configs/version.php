<?php
return array(
'pc_version' => 'V9.1.1',	//phpcms 版本号
'pc_release' => '20110603',	//phpcms 更新日期
);
?>