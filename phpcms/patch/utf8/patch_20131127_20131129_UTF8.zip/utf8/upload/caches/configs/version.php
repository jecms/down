<?php
return array(
'pc_version' => 'V9.5.2',	//phpcms 版本号
'pc_release' => '20131129',	//phpcms 更新日期
);
?>