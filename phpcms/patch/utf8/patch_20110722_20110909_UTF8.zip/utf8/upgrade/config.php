<?php
return array(
				'steps'=>array('ext','version'),//本升级程序需要使用的升级步骤。
				'from_version'=>'V9.1.6',//需要升级的程序
				'from_release'=>'20110722',//需要升级的程序版本
				'to_version'=>'V9.1.7',//升级到的程序
				'to_release'=>'20110909',//升级到的程序版本
				'version_check'=>'1',//是否对版本进行严格检查
				'version_description'=>'1、优化了会员前台投稿流程
2、修复批量添加栏目，栏目名称多余空格的问题
3、修复了表单向导图片无法上传的问题
4、修复了相关功能BUG及安全问题',
);