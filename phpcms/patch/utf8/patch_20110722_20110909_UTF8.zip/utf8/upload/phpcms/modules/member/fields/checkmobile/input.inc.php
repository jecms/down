	function checkmobile($field, $value) {
	if(ROUTE_A=='register' || defined('IN_ADMIN')) {
		if(!preg_match('/^1([0-9]{9})/',$value)) showmessage('请输入正确的手机号码');
		if(!defined('IN_ADMIN')) {
			if(trim($_POST['mobile_verify'])=='') showmessage('手机验证码不能为空');
			$sms_report_db = pc_base::load_model('sms_report_model');
			$posttime = SYS_TIME-300;
			$where = "`mobile`='$mobile' AND `posttime`>'$posttime'";
			$r = $sms_report_db->get_one($where);
			if(!$r || $r['id_code']!=$_POST['mobile_verify']) showmessage('请输入正确的手机号码');
		}
			return $value;
		}
	}
