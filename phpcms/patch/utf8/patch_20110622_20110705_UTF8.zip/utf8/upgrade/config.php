<?php
return array(
				'steps'=>array('ext','version'),//本升级程序需要使用的升级步骤。
				'from_version'=>'V9.1.4',//需要升级的程序
				'from_release'=>'20110622',//需要升级的程序版本
				'to_version'=>'V9.1.5',//升级到的程序
				'to_release'=>'20110705',//升级到的程序版本
				'version_check'=>'1',//是否对版本进行严格检查
				'version_description'=>'1、优化error_log安全访问限制。
2、新增安装的时候，自动删除安装install 目录。
3、修正会员验证BUG，当管理员开启审核，出现无法注册问题。
4、修复栏目更新问题。
5、全性修改 及 会员留言程序完善。
6、修正 投票代码错误。',//版本介绍
);