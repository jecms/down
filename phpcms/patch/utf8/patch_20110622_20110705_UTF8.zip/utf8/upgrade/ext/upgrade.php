<?php

$type_db = pc_base::load_model('type_model');
$type_db->update(array('typedir'=>'special'), array('module'=>'search', 'parentid'=>0, 'name'=>'专题'));
?>