<?php
return array(
'pc_version' => 'V9.4.1',	//phpcms 版本号
'pc_release' => '20130829',	//phpcms 更新日期
);
?>