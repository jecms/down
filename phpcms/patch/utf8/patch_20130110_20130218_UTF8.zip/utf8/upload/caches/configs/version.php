<?php
return array(
'pc_version' => 'V9.2.8',	//phpcms 版本号
'pc_release' => '20130218',	//phpcms 更新日期
);
?>