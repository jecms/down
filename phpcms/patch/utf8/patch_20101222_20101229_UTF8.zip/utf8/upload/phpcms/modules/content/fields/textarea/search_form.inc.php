	function text($field, $value, $fieldinfo)
	{
		return form::text($field, $field, $value, 'text', 15);
	}
