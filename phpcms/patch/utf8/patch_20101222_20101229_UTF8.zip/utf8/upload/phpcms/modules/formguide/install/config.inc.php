<?php 
defined('IN_PHPCMS') or exit('Access Denied');
defined('INSTALL') or exit('Access Denied');

$module = 'formguide';
$modulename = '表单向导模块';
$introduce = '独立模块';
$author = 'phpcms Team';
$authorsite = 'http://www.phpcms.cn';
$authoremail = '';
?>