	function image($field, $value) {
		return trim($value);
	}
