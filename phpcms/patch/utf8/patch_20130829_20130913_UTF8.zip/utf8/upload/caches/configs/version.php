<?php
return array(
'pc_version' => 'V9.4.2',	//phpcms 版本号
'pc_release' => '20130913',	//phpcms 更新日期
);
?>