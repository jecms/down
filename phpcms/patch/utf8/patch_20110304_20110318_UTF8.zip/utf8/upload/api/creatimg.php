<?php
defined('IN_PHPCMS') or exit('No permission resources.'); 
$txt = trim($_GET['txt']);
if(extension_loaded('gd') && $txt ) {
	header ("Content-type: image/png");
	$txt = urldecode(sys_auth($txt, 'DECODE'));
	$font_size = 16;
	$fontfile = PC_PATH.'libs'.DIRECTORY_SEPARATOR.'data'.DIRECTORY_SEPARATOR.'font'.DIRECTORY_SEPARATOR.'georgia.ttf';	
	
	//计算文本写入后的宽度，右下角 X 位置-左下角 X 位置
	
	$image_info = imagettfbbox($font_size,0,$fontfile,$txt);
	$imageX = $image_info[2]-$image_info[0]+10;
	$im = @imagecreatetruecolor ($imageX, 30) or die ("Cannot Initialize new GD image stream");
	$white= imagecolorallocate($im, 255, 255, 255);
	$font_color= imagecolorallocate($im,255,0,0);
	imagefilledrectangle($im, 0, 0, $imageX, 30, $white);

	if(file_exists($fontfile)){
		$txt = iconv("GB2312","UTF-8",$txt);
		imagettftext($im, $font_size, 0, 5, 20, $font_color, $fontfile, $txt);
	} else {
		$fonttype = intval($fonttype);
		imagestring ($im, 5, 0, 0,$txt, $font_color);
	}
	imagepng ($im);
	imagedestroy ($im);	
}
?>