ALTER TABLE `phpcms_position_data` ADD `extention` CHAR( 30 ) NOT NULL AFTER `listorder` ;
ALTER TABLE `phpcms_position_data` ADD `expiration` INT UNSIGNED NOT NULL DEFAULT '0' AFTER `listorder`;
CREATE TABLE IF NOT EXISTS `phpcms_extend_setting` (`id` smallint(5) unsigned NOT NULL AUTO_INCREMENT, `key` char(30) NOT NULL, `data` mediumtext, PRIMARY KEY (`id`), KEY `key` (`key`)) TYPE=MyISAM;