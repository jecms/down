<?php
$linkage_db = pc_base::load_model('linkage_model');
if (!$linkage_db->field_exists('child')) {
	$linkage_db->query("ALTER TABLE `phpcms_linkage` ADD `child` TINYINT( 1 ) UNSIGNED NOT NULL DEFAULT '0' AFTER `parentid`");
	$linkage_db->query("ALTER TABLE `phpcms_linkage` ADD `arrchildid` MEDIUMTEXT NOT NULL AFTER `child`;");
}
?>