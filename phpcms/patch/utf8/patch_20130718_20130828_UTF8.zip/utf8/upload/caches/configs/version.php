<?php
return array(
'pc_version' => 'V9.4.0',	//phpcms 版本号
'pc_release' => '20130828',	//phpcms 更新日期
);
?>