<?php
$tmp_db = pc_base::load_model('member_model');
$tmp_db->query("ALTER TABLE  `phpcms_member` CHANGE  `connectid`  `connectid` CHAR( 40 )  NOT NULL DEFAULT  ''");
unlink(PC_PATH.'libs/functions/autoload/tmp_connectid.func.php');
?>