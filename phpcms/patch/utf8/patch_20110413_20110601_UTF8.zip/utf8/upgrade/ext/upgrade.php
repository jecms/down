<?php

$hits_db = pc_base::load_model('hits_model');
if (!$hits_db->field_exists('catid')) {
	$hits_db->query("ALTER TABLE `phpcms_hits` ADD `catid` SMALLINT UNSIGNED NOT NULL DEFAULT '0' AFTER `hitsid` ");
} else {
	$hits_db->query("ALTER TABLE `phpcms_hits` CHANGE `catid` `catid` SMALLINT( 5 ) UNSIGNED NOT NULL DEFAULT '0'");
}

$member_db = pc_base::load_model('member_model');
if (!$member_db->field_exists('connectid')) {
	$member_db->query("ALTER TABLE `phpcms_member` ADD `connectid` CHAR( 15 ) NOT NULL");
} else {
	$member_db->query("ALTER TABLE `phpcms_member` CHANGE `connectid` `connectid` CHAR( 15 ) NOT NULL");
}
if (!$member_db->field_exists('from')) {
	$member_db->query("ALTER TABLE `phpcms_member` ADD `from` CHAR( 10 ) NOT NULL");
} else {
	$member_db->query("ALTER TABLE `phpcms_member` CHANGE `from` `from` CHAR( 10 ) NOT NULL");
}
?>