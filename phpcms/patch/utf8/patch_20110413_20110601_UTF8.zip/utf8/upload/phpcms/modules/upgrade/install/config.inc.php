<?php 
defined('IN_PHPCMS') or exit('Access Denied');
defined('INSTALL') or exit('Access Denied');
$module = 'upgrade';
$modulename = '在线升级';
$introduce = '在线升级';
$author = 'phpcms Team';
$authorsite = 'http://www.phpcms.cn';
$authoremail = 'admin@phpcms.cn';
?>