<?php
$LANG['member_init'] = '管理中心';
$LANG['account_manage'] = '账号管理';
$LANG['favorite'] = '收藏';
$LANG['123'] = '123';
$LANG['pay'] = '在线充值';
$LANG['business_centre'] = '商务中心';
?>