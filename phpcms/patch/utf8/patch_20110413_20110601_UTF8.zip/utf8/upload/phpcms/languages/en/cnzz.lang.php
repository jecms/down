<?php
$LANG['reg_msg'] = 'You have not applied for CNZZ web statistics, apply now?<br><br><input type="button" onclick="location.href=\'?m=cnzz&c=index&a=public_regcnzz\'" value="Yes"> <input type="button" onclick="history.back();" value=" No">';
$LANG['application_fails'] = 'Failed to apply. Please try again later';
$LANG['donot_connect_server'] = 'Could not connect to CNZZ server';
$LANG['has_been_registered'] = 'Already registered';