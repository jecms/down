<?php
return array(
'pc_version' => 'V9.5.1',	//phpcms 版本号
'pc_release' => '20131127',	//phpcms 更新日期
);
?>