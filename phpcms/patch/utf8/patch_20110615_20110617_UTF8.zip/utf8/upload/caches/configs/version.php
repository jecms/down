<?php
return array(
'pc_version' => 'V9.1.3',	//phpcms 版本号
'pc_release' => '20110617',	//phpcms 更新日期
);
?>