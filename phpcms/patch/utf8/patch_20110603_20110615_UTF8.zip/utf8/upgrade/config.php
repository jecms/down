<?php
return array(
				'steps'=>array('ext','version'),//本升级程序需要使用的升级步骤。
				'from_version'=>'V9.1.1',//需要升级的程序
				'from_release'=>'20110603',//需要升级的程序版本
				'to_version'=>'V9.1.2',//升级到的程序
				'to_release'=>'20110615',//升级到的程序版本
				'version_check'=>'1',//是否对版本进行严格检查
				'version_description'=>'插件应用中心',//版本介绍
);