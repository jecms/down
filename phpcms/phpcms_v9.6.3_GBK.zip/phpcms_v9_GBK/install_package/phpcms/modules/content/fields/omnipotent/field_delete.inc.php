<?php 
$db->query("ALTER TABLE `$tablename` DROP `$field`");
?>