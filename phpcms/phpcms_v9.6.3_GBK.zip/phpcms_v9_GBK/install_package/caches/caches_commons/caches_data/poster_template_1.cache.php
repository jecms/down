<?php
return array (
  'banner' => 
  array (
    'name' => '���κ��',
    'select' => '0',
    'padding' => '0',
    'size' => '1',
    'option' => '0',
    'num' => '1',
    'iscore' => '1',
    'type' => 
    array (
      'images' => 'ͼƬ',
      'flash' => '����',
    ),
  ),
  'fixure' => 
  array (
    'name' => '�̶�λ��',
    'align' => 'align',
    'select' => '1',
    'padding' => '1',
    'size' => '1',
    'option' => '0',
    'num' => '1',
    'iscore' => '1',
    'type' => 
    array (
      'images' => 'ͼƬ',
      'flash' => '����',
    ),
  ),
  'float' => 
  array (
    'name' => 'Ư���ƶ�',
    'select' => '0',
    'padding' => '1',
    'size' => '1',
    'option' => '0',
    'num' => '1',
    'iscore' => '1',
    'type' => 
    array (
      'images' => 'ͼƬ',
      'flash' => '����',
    ),
  ),
  'couplet' => 
  array (
    'name' => '�������',
    'align' => 'scroll',
    'select' => '0',
    'padding' => '1',
    'size' => '1',
    'option' => '0',
    'num' => '2',
    'iscore' => '1',
    'type' => 
    array (
      'images' => 'ͼƬ',
      'flash' => '����',
    ),
  ),
  'imagechange' => 
  array (
    'name' => 'ͼƬ�ֻ����',
    'select' => '0',
    'padding' => '0',
    'size' => '1',
    'option' => '1',
    'num' => '1',
    'iscore' => '1',
    'type' => 
    array (
      'images' => 'ͼƬ',
    ),
  ),
  'imagelist' => 
  array (
    'name' => 'ͼƬ�б����',
    'select' => '0',
    'padding' => '0',
    'size' => '1',
    'option' => '1',
    'num' => '1',
    'iscore' => '1',
    'type' => 
    array (
      'images' => 'ͼƬ',
    ),
  ),
  'text' => 
  array (
    'name' => '���ֹ��',
    'select' => '0',
    'padding' => '0',
    'size' => '0',
    'option' => '1',
    'num' => '1',
    'iscore' => '1',
    'type' => 
    array (
      'text' => '����',
    ),
  ),
  'code' => 
  array (
    'name' => '������',
    'type' => 
    array (
      'text' => '����',
    ),
    'num' => 1,
    'iscore' => 1,
    'option' => 0,
  ),
);
?>