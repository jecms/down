<?php

return array (
	'default' => array (
		'hostname' => 'localhost',
		'port' => 3306,
		'database' => 'phpcmsv9',
		'username' => '',
		'password' => '',
		'tablepre' => 'v9_',
		'charset' => 'gbk',
		'type' => 'mysqli',
		'debug' => true,
		'pconnect' => 0,
		'autoconnect' => 0
		),
);

?>